# Auctioneer
Auction Site done with Java Spring MVC. Uses Security, Schedules, Java mailer, JPA, design patterns like factory, observer, strategy etc.

https://youtu.be/d4--SeBHCEc 
