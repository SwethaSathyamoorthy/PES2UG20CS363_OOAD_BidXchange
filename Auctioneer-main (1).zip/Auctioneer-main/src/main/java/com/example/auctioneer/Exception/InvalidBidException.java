package com.example.auctioneer.Exception;

import java.io.Serializable;

public class InvalidBidException extends RuntimeException implements Serializable {
    private static final long serialVersionUID = 1L;

    public InvalidBidException(String message) {
        super(message);
    }
}
