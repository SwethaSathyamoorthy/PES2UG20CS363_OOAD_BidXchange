package com.example.auctioneer.Service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.example.auctioneer.Model.Item;

public interface ItemService{
    void saveItem(Item item);
    void deleteItem(Long id);
	void saveItem(Item item, MultipartFile file) throws IOException;
}
