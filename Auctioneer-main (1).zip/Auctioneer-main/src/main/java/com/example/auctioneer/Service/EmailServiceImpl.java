package com.example.auctioneer.Service;

import com.example.auctioneer.Model.Auction;
import com.example.auctioneer.Model.Bid;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
@Service
public class EmailServiceImpl implements EmailService{

    private static EmailServiceImpl instance;

    private EmailServiceImpl() {
        // Private constructor to prevent instantiation outside of the class
    }

    public static EmailServiceImpl getInstance() {
        if (instance == null) {
            synchronized (EmailServiceImpl.class) {
                if (instance == null) {
                    instance = new EmailServiceImpl();
                    new JavaMailSenderImpl();
                }
            }
        }
        return instance;
    }

	@Override
	public void sendBidEmail(Bid bid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendAuctionEmail(Auction auction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendWinnersEmailBidder(Auction auction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendWinnersEmailAuctioneer(Auction auction) {
		// TODO Auto-generated method stub
		
	}

    // Other methods for sending emails
}
