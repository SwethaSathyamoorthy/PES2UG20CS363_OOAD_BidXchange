package com.example.auctioneer.Service;


import com.example.auctioneer.Model.Category;

public interface CategoryService {
    public Category getCategoryById(Long id);
}
