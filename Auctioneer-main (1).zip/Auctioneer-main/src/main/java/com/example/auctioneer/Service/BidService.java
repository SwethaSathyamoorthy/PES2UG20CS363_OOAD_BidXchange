package com.example.auctioneer.Service;

import org.springframework.stereotype.Service;

import com.example.auctioneer.Model.Auction;
import com.example.auctioneer.Model.Bid;
import com.example.auctioneer.Repository.AuctionRepository;
import com.example.auctioneer.Repository.BidRepository;
import com.example.auctioneer.Exception.InvalidBidException;

@Service
public class BidService {
    private final BidRepository bidRepository;
    private final AuctionRepository auctionRepository;

    public BidService(BidRepository bidRepository, AuctionRepository auctionRepository) {
        this.bidRepository = bidRepository;
        this.auctionRepository = auctionRepository;
    }

    public Bid placeBid(Long auctionId, Bid bid) {
        Auction auction = auctionRepository.findById(auctionId)
                .orElseThrow();
        
        if (bid.getAmount() > auction.getHighestBid().getAmount()) {
            auction.setHighestBid(bid);
            bid.setAuction(auction);
            bidRepository.save(bid);
            return bid;
        } else {
            throw new InvalidBidException("Bid amount is not higher than current highest bid");
        }
    }
}
