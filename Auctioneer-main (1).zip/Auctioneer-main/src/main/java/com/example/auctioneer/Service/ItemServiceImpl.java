package com.example.auctioneer.Service;

import com.example.auctioneer.Model.Item;
import com.example.auctioneer.Repository.ItemRepository;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
@Service
public class ItemServiceImpl implements ItemService{

    @Autowired
    ItemRepository itemRepository;

    @Override
    public void saveItem(Item item) {
        itemRepository.save(item);
    }

    @Override
    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }

	@Override
	public void saveItem(Item item, MultipartFile file) throws IOException {
		// TODO Auto-generated method stub
		
	}
}
