package com.example.auctioneer.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.auctioneer.Model.Auction;
import com.example.auctioneer.Model.Bid;

@Service
public class AuctionFacade {
    private AuctionService auctionService;
    private BidService bidService;

    public AuctionFacade(AuctionService auctionService, BidService bidService) {
        this.auctionService = auctionService;
        this.bidService = bidService;
    }

    public Auction createAuction(Auction auction) {
        return auctionService.deleteAuction(auction);
    }

    public Auction getAuctionById(Long id) {
        return auctionService.findAuctionById(id);
    }

    public List<Auction> getAllAuctions() {
        return auctionService.getAllAuctions();
    }

    public Bid placeBid(Long auctionId, Bid bid) {
        return bidService.placeBid(auctionId, bid);
    }

    public void deleteAuctionById(Long id) {
        auctionService.deleteAuction(id);
    }
}
