package com.example.auctioneer.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.example.auctioneer.Model.Auction;
import com.example.auctioneer.Model.Bid;

public interface Facade {
    Auction createAuction(Auction auctionDTO);
    Auction getAuction(Long id);
    Page<Auction> getAllAuctions(PageRequest page);
    Page<Auction> getAuctionsByCategory(String category, PageRequest page);
    Bid placeBid(Bid bidDTO);
}